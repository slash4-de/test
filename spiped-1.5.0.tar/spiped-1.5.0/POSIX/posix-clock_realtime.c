#include <time.h>

int main() {return CLOCK_REALTIME;}
