#include <sys/socket.h>

int main() {return MSG_NOSIGNAL;}
